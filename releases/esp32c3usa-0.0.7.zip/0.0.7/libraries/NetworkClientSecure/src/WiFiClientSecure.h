#pragma once
#include "NetworkClientSecure.h"
typedef NetworkClientSecure WiFiClientSecure;
